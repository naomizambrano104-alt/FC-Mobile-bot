const {state,save}=require("./store");
const pool=[
["Guardameta","POR",74],["Central muro","DFC",77],["Lateral veloz","LI",76],["Defensa seguro","DFC",78],["Carrilero","LD",76],
["Pivote","MCD",79],["Organizador","MC",81],["Creador","MCO",83],["Extremo zurdo","EI",82],["Goleador","DC",84],
["Extremo derecho","ED",81],["Arquero élite","POR",90],["Central élite","DFC",91],["Motor del medio","MC",92],
["Delantero leyenda","DC",95],["Superestrella","MCO",97]];
const shop=[["Arquero élite","POR",90,18000],["Central élite","DFC",91,22000],["Motor del medio","MC",92,26000],["Delantero leyenda","DC",95,40000],["Superestrella","MCO",97,55000]];
const user=id=>state.users[id]||null;
function create(id,name){if(!user(id)){state.users[id]={id,club:name.slice(0,24),coins:50000,wins:0,draws:0,losses:0,gf:0,ga:0,players:[],starters:[],eventDay:null};save();}return user(id);}
function add(u,p){const x={id:Date.now()+"-"+Math.random().toString(36).slice(2,7),...p};u.players.push(x);return x;}
function pack(u){if(u.coins<5000)return null;u.coins-=5000;const out=[];for(let i=0;i<3;i++){const r=Math.random();let p=r<.01?pool[15]:r<.07?pool[11+Math.floor(Math.random()*4)]:r<.3?pool[5+Math.floor(Math.random()*6)]:pool[Math.floor(Math.random()*11)];out.push(add(u,{name:p[0],pos:p[1],rating:p[2],rarity:p[2]>=97?"Ícono":p[2]>=90?"Élite":p[2]>=82?"Especial":"Base"}));}save();return out;}
const best=u=>[...u.players].sort((a,b)=>b.rating-a.rating).slice(0,11);
const lineup=u=>u.players.filter(p=>(u.starters||[]).includes(p.id).length?false:true);
function selected(u){const s=u.players.filter(p=>(u.starters||[]).includes(p.id));return s.length?s:best(u);}
const grl=u=>{const a=selected(u);return a.length?Math.round(a.reduce((n,p)=>n+p.rating,0)/a.length):0;};
function formation(u,f){if(!["4-3-3","4-4-2","4-2-3-1","3-5-2"].includes(f))return false;u.formation=f;u.starters=best(u).map(p=>p.id);save();return true;}
function match(a,b){const ra=grl(a),rb=grl(b);const goals=adv=>Math.max(0,Math.min(6,Math.floor(Math.random()*2+Math.random()*2.2+adv)));const x=goals((ra-rb)/35),y=goals((rb-ra)/35);a.gf+=x;a.ga+=y;b.gf+=y;b.ga+=x;if(x>y){a.wins++;b.losses++;a.coins+=1500;}else if(y>x){b.wins++;a.losses++;b.coins+=500;}else{a.draws++;b.draws++;a.coins+=800;b.coins+=800;}save();return{ra,rb,x,y};}
function buy(u,n){const p=shop[n-1];if(!p||u.coins<p[3])return false;u.coins-=p[3];add(u,{name:p[0],pos:p[1],rating:p[2],rarity:"Mercado"});save();return true;}
function sell(u,n){const p=u.players[n-1];if(!p)return null;u.players.splice(n-1,1);u.starters=u.starters.filter(id=>id!==p.id);const value=Math.max(500,p.rating*65);u.coins+=value;save();return{p,value};}
function standings(){return Object.values(state.users).sort((a,b)=>(b.wins*3+b.draws)-(a.wins*3+a.draws)).slice(0,10);}
module.exports={user,create,pack,best,selected,grl,formation,match,buy,sell,shop,standings,save};