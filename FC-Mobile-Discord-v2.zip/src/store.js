const fs=require("node:fs"), path=require("node:path");
const dir=process.env.DATA_DIR||path.join(process.cwd(),"data");
const file=path.join(dir,"fc-mobile.json");
const state={users:{}};
function save(){fs.mkdirSync(dir,{recursive:true});const tmp=file+".tmp";fs.writeFileSync(tmp,JSON.stringify(state,null,2));fs.renameSync(tmp,file);}
function load(){fs.mkdirSync(dir,{recursive:true});if(fs.existsSync(file)){try{Object.assign(state,JSON.parse(fs.readFileSync(file,"utf8")));}catch(e){console.error("Error leyendo datos",e);}}else save();}
module.exports={state,load,save};