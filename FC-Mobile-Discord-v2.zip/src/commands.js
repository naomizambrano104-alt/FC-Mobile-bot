const {SlashCommandBuilder}=require("discord.js");
module.exports=[
new SlashCommandBuilder().setName("inicio").setDescription("Crea tu club").addStringOption(o=>o.setName("club").setDescription("Nombre del club").setRequired(true)),
new SlashCommandBuilder().setName("perfil").setDescription("Tu perfil y estadísticas"),
new SlashCommandBuilder().setName("pack").setDescription("Abre un sobre de 3 jugadores"),
new SlashCommandBuilder().setName("plantilla").setDescription("Mira tus jugadores"),
new SlashCommandBuilder().setName("alineacion").setDescription("Elige formación").addStringOption(o=>o.setName("formacion").setDescription("Formación").setRequired(true).addChoices(...["4-3-3","4-4-2","4-2-3-1","3-5-2"].map(x=>({name:x,value:x})))),
new SlashCommandBuilder().setName("amistoso").setDescription("Reta a otro club").addUserOption(o=>o.setName("rival").setDescription("Rival").setRequired(true)),
new SlashCommandBuilder().setName("liga").setDescription("Clasificación global"),
new SlashCommandBuilder().setName("eventos").setDescription("Información de eventos"),
new SlashCommandBuilder().setName("evento").setDescription("Juega el desafío diario"),
new SlashCommandBuilder().setName("tienda").setDescription("Mira el mercado"),
new SlashCommandBuilder().setName("comprar").setDescription("Compra jugador").addIntegerOption(o=>o.setName("numero").setDescription("Número de tienda").setRequired(true).setMinValue(1).setMaxValue(5)),
new SlashCommandBuilder().setName("vender").setDescription("Vende jugador").addIntegerOption(o=>o.setName("numero").setDescription("Número de plantilla").setRequired(true).setMinValue(1)),
new SlashCommandBuilder().setName("ayuda").setDescription("Lista de comandos")].map(x=>x.toJSON());