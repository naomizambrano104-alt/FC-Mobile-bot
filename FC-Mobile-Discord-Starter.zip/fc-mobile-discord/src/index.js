require("dotenv").config();
const { Client, GatewayIntentBits, EmbedBuilder } = require("discord.js");
const game = require("./game");
const db = require("./db");

const client = new Client({ intents: [GatewayIntentBits.Guilds] });
const shop = [
  { name: "Portero estrella", position: "POR", rating: 90, price: 18000 },
  { name: "Defensa élite", position: "DFC", rating: 91, price: 22000 },
  { name: "Mago del medio", position: "MC", rating: 92, price: 26000 },
  { name: "Crack mundial", position: "DC", rating: 95, price: 40000 }
];

function money(n) { return `${n.toLocaleString("es-PA")} monedas`; }
function noClub(i) { return !game.getUser(i); }

client.once("ready", () => console.log(`FC Mobile conectado como ${client.user.tag}`));

client.on("interactionCreate", async interaction => {
  if (!interaction.isChatInputCommand()) return;
  const id = interaction.user.id;
  try {
    if (interaction.commandName === "inicio") {
      const club = interaction.options.getString("club").slice(0, 24);
      const existed = game.getUser(id);
      if (existed) return interaction.reply({ content: `Ya tienes el club **${existed.club_name}**.`, ephemeral: true });
      game.createClub(id, club);
      return interaction.reply(`🏟️ ¡Bienvenido, **${club}**! Tu club recibe 50.000 monedas. Usa **/pack** para fichar tus primeros jugadores.`);
    }
    if (noClub(id)) return interaction.reply({ content: "Primero crea tu club con **/inicio**.", ephemeral: true });

    if (interaction.commandName === "perfil") {
      const u = game.getUser(id);
      return interaction.reply(`🏟️ **${u.club_name}**\n🪙 ${money(u.coins)}\n⭐ GRL: **${game.teamRating(id) || "Sin plantilla"}**\n🏆 ${u.wins} V · ${u.draws} E · ${u.losses} D`);
    }
    if (interaction.commandName === "pack") {
      const u = game.getUser(id);
      if (u.coins < 5000) return interaction.reply({ content: "Necesitas 5.000 monedas para abrir un pack.", ephemeral: true });
      db.prepare("UPDATE users SET coins=coins-5000 WHERE user_id=?").run(id);
      const players = game.openPack(id);
      const embed = new EmbedBuilder().setTitle("🎁 ¡PACK ABIERTO!").setColor(0x1d9bf0)
        .setDescription(players.map(p => `**${p.name}** · ${p.position} · ⭐ ${p.rating} GRL · ${p.rarity}`).join("\n"));
      return interaction.reply({ embeds: [embed], content: "Se descontaron 5.000 monedas." });
    }
    if (interaction.commandName === "plantilla") {
      const players = game.getPlayers(id);
      if (!players.length) return interaction.reply("Todavía no tienes jugadores. ¡Abre tu primer **/pack**!");
      const embed = new EmbedBuilder().setTitle(`👥 Plantilla de ${game.getUser(id).club_name}`)
        .setColor(0x2ecc71).setDescription(players.map((p,i) => `**${i+1}. ${p.name}** · ${p.position} · ${p.rating} GRL`).join("\n"));
      return interaction.reply({ embeds: [embed] });
    }
    if (interaction.commandName === "tienda") {
      const embed = new EmbedBuilder().setTitle("🛒 Mercado de jugadores").setColor(0xf1c40f)
        .setDescription(shop.map((p,i) => `**${i+1}. ${p.name}** · ${p.position} · ${p.rating} GRL · 🪙 ${money(p.price)}`).join("\n"));
      return interaction.reply({ embeds: [embed], content: "Compra con **/comprar numero:**." });
    }
    if (interaction.commandName === "comprar") {
      const n = interaction.options.getInteger("numero");
      const p = shop[n-1];
      if (!p) return interaction.reply({ content: "Número inválido. Mira **/tienda**.", ephemeral: true });
      const u = game.getUser(id);
      if (u.coins < p.price) return interaction.reply({ content: "No tienes monedas suficientes.", ephemeral: true });
      db.prepare("UPDATE users SET coins=coins-? WHERE user_id=?").run(p.price,id);
      game.db.prepare("INSERT INTO players(user_id,name,position,rating,rarity,price) VALUES(?,?,?,?,?,?)")
        .run(id,p.name,p.position,p.rating,"Tienda",p.price);
      return interaction.reply(`✅ Fichaste a **${p.name} (${p.rating} GRL)** por ${money(p.price)}.`);
    }
    if (interaction.commandName === "amistoso") {
      const rival = interaction.options.getUser("rival");
      if (rival.bot || rival.id === id) return interaction.reply({ content: "Elige a otro jugador humano.", ephemeral: true });
      if (noClub(rival.id)) return interaction.reply({ content: "Tu rival todavía no ha creado su club.", ephemeral: true });
      const result = game.simulateMatch(id, rival.id);
      const a = game.getUser(id), b = game.getUser(rival.id);
      const winner = result.goalsA > result.goalsB ? id : result.goalsA < result.goalsB ? rival.id : null;
      if (!winner) {
        db.prepare("UPDATE users SET draws=draws+1 WHERE user_id IN (?,?)").run(id,rival.id);
      } else {
        db.prepare("UPDATE users SET wins=wins+1 WHERE user_id=?").run(winner);
        db.prepare("UPDATE users SET losses=losses+1 WHERE user_id=?").run(winner === id ? rival.id : id);
      }
      return interaction.reply(`⚽ **AMISTOSO FINALIZADO**\n🏟️ ${a.club_name} **${result.goalsA} - ${result.goalsB}** ${b.club_name}\n⭐ GRL: ${result.a} vs ${result.b}\n${winner ? `🏆 Ganador: <@${winner}>` : "🤝 ¡Empate!"}`);
    }
  } catch (err) {
    console.error(err);
    if (interaction.replied || interaction.deferred) return interaction.followUp({ content: "Hubo un error procesando el comando.", ephemeral: true });
    return interaction.reply({ content: "Hubo un error procesando el comando.", ephemeral: true });
  }
});

client.login(process.env.DISCORD_TOKEN);