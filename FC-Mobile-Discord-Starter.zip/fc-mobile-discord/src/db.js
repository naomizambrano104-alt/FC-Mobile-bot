const Database = require("better-sqlite3");
const db = new Database("data.sqlite");

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  user_id TEXT PRIMARY KEY,
  club_name TEXT NOT NULL,
  coins INTEGER NOT NULL DEFAULT 50000,
  wins INTEGER NOT NULL DEFAULT 0,
  draws INTEGER NOT NULL DEFAULT 0,
  losses INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS players (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id TEXT NOT NULL,
  name TEXT NOT NULL,
  position TEXT NOT NULL,
  rating INTEGER NOT NULL,
  rarity TEXT NOT NULL DEFAULT 'Base',
  price INTEGER NOT NULL DEFAULT 0,
  starter INTEGER NOT NULL DEFAULT 0
);
`);

module.exports = db;