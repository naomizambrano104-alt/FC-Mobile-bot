const db = require("./db");

const PLAYER_POOL = [
  ["Portero joven", "POR", 78], ["Defensa veloz", "DFC", 80],
  ["Lateral ofensivo", "LI", 79], ["Central fuerte", "DFC", 82],
  ["Lateral derecho", "LD", 78], ["Mediocentro", "MC", 81],
  ["Volante creativo", "MCO", 84], ["Pivote", "MCD", 80],
  ["Extremo izquierdo", "EI", 83], ["Delantero goleador", "DC", 85],
  ["Extremo derecho", "ED", 82], ["Arquero estrella", "POR", 90],
  ["Defensa élite", "DFC", 91], ["Mago del medio", "MC", 92],
  ["Crack mundial", "DC", 95]
];

function getUser(id) {
  return db.prepare("SELECT * FROM users WHERE user_id=?").get(id);
}
function createClub(id, name) {
  db.prepare("INSERT OR IGNORE INTO users(user_id,club_name) VALUES(?,?)").run(id, name);
  return getUser(id);
}
function getPlayers(id) {
  return db.prepare("SELECT * FROM players WHERE user_id=? ORDER BY rating DESC").all(id);
}
function addPlayer(id, p) {
  db.prepare("INSERT INTO players(user_id,name,position,rating,rarity,price) VALUES(?,?,?,?,?,?)")
    .run(id, p.name, p.position, p.rating, p.rarity, p.price);
}
function openPack(id) {
  const chosen = [];
  for (let i = 0; i < 3; i++) {
    const roll = Math.random();
    let p;
    if (roll < 0.015) p = PLAYER_POOL[14];
    else if (roll < 0.08) p = PLAYER_POOL[11 + Math.floor(Math.random() * 3)];
    else if (roll < 0.30) p = PLAYER_POOL[5 + Math.floor(Math.random() * 6)];
    else p = PLAYER_POOL[Math.floor(Math.random() * 11)];
    const rarity = p[2] >= 95 ? "Épico" : p[2] >= 90 ? "Élite" : p[2] >= 84 ? "Especial" : "Base";
    const player = { name: p[0], position: p[1], rating: p[2], rarity, price: p[2] * 100 };
    addPlayer(id, player);
    chosen.push(player);
  }
  return chosen;
}
function teamRating(id) {
  const players = getPlayers(id);
  if (!players.length) return 0;
  const starters = players.slice(0, 11);
  return Math.round(starters.reduce((s, p) => s + p.rating, 0) / starters.length);
}
function simulateMatch(aId, bId) {
  const a = teamRating(aId), b = teamRating(bId);
  const score = (rating, opponent) => {
    const strength = Math.max(0.25, Math.min(1.8, 0.65 + (rating - opponent) / 100));
    return Math.min(6, Math.floor(Math.random() * 3 + Math.random() * strength * 2));
  };
  return { a, b, goalsA: score(a,b), goalsB: score(b,a) };
}
module.exports = { db, getUser, createClub, getPlayers, openPack, teamRating, simulateMatch };