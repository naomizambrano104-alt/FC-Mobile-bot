require("dotenv").config();
const { REST, Routes, SlashCommandBuilder } = require("discord.js");

const commands = [
  new SlashCommandBuilder().setName("inicio").setDescription("Crea tu club de FC Mobile")
    .addStringOption(o => o.setName("club").setDescription("Nombre de tu club").setRequired(true)),
  new SlashCommandBuilder().setName("perfil").setDescription("Mira tu perfil y monedas"),
  new SlashCommandBuilder().setName("pack").setDescription("Abre un pack de 3 jugadores"),
  new SlashCommandBuilder().setName("plantilla").setDescription("Mira tus jugadores"),
  new SlashCommandBuilder().setName("tienda").setDescription("Mira jugadores disponibles"),
  new SlashCommandBuilder().setName("comprar").setDescription("Compra un jugador de la tienda")
    .addIntegerOption(o => o.setName("numero").setDescription("Número del jugador").setRequired(true)),
  new SlashCommandBuilder().setName("amistoso").setDescription("Juega un amistoso simulado")
    .addUserOption(o => o.setName("rival").setDescription("Usuario rival").setRequired(true))
].map(c => c.toJSON());

const rest = new REST({ version: "10" }).setToken(process.env.DISCORD_TOKEN);
(async () => {
  try {
    await rest.put(Routes.applicationGuildCommands(process.env.CLIENT_ID, process.env.GUILD_ID), { body: commands });
    console.log("Comandos registrados en el servidor.");
  } catch (e) { console.error(e); process.exit(1); }
})();